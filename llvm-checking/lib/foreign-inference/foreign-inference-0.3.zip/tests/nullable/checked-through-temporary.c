int f(int *i) {
  int * p = i;

  if(p) return *p;

  return 0;
}
