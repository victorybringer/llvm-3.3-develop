#include "base.h"

void f(int * n) {
  if(n) argOneNotNull(n, 0);
}
