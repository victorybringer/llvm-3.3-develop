void f(int (*func)(int)) {
  func(5);
}
