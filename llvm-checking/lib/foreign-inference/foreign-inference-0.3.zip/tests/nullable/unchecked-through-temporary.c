int f(int *i) {
  int * p = i;

  return *p;
}
