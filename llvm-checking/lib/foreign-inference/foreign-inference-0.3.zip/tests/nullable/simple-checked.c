int f(int *i) {
  if(i)
    return *i;

  return 0;
}
