int * p;
int f(int *i) {
  p = i;

  return *p;
}
