#include "base.h"

int f(int * arr, int * arr2) {
  return allArgsNullable(arr, arr2);
}
