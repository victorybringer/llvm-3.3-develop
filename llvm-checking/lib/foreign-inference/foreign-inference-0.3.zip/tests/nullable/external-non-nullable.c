#include "base.h"

int f(int * arr, int * arr2) {
  return argTwoNotNull(arr, arr2);
}
