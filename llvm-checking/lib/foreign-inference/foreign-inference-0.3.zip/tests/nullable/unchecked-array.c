extern int x;
int f(int *a) {
  return a[x];
}
