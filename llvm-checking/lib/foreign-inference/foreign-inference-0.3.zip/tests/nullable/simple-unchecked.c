int f(int *i) {
  return *i;
}
