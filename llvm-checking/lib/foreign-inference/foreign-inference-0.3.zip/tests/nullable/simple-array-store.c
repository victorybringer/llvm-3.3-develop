extern int x;
void f(int * arr) {
  arr[x] = 1;
}
