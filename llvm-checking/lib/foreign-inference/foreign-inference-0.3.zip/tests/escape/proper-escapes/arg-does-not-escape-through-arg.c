int* f(int * p, int *q) {
  q = p;
  return q;
}
