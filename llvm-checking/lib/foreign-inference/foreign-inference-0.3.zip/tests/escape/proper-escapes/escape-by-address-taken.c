int **global;
void f(int *p)
{
  global = &p;
}
