extern int * g;

void f(int * p){
  g = p;
}
