int x;
void f(int * p) {
  x = *p;
}
