extern int ** g;

void f(int * p, int idx){
  g[idx] = p;
}
