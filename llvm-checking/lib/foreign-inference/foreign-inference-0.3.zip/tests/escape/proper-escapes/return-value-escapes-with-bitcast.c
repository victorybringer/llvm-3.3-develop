void* f(int * p) {
  return p;
}
