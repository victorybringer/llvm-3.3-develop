int* f(int * p) {
  return p;
}
