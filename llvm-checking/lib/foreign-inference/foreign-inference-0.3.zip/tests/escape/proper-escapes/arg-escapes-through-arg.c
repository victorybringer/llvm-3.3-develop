void f(int * p, int **pp) {
  *pp = p;
}
