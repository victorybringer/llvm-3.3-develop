void f(int x, int *out) {
  *out = x;
}
