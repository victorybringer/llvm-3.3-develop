extern int x;
int* f(int ** arr) {
  x = arr[5][x];
  return arr[x];
}
