int f(int * ptrParam) {
  *ptrParam = 10;

  return 5;
}
