int x;
int f(int *arr1, double * arr2) {
  return arr1[5] / arr2[x];
}
