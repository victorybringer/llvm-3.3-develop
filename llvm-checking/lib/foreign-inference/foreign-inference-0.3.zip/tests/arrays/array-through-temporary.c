int x;
int f(int *arr1, double * arr2) {
  int * tmp = arr1;
  return tmp[5] / arr2[x];
}
