int x;
int f(int ***arr) {
  return arr[5][25][x];
}
