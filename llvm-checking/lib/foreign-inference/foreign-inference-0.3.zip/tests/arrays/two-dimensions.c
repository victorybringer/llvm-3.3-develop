int f(int **arr) {
  return arr[5][25];
}
