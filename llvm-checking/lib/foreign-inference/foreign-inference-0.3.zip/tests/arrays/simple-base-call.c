#include "base.h"

void f(int * oneDim) {
  int x;
  oneDimAccess(oneDim, &x);
}
