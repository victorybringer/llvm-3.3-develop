#include <stdlib.h>

void f(int * p) {
  free(p);
}
