#include <stdio.h>

void f(char * p) {
  puts(p);
}
