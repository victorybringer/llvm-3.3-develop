int g;

void notNullPtr(int *i) {
  g = *i;
}
