int g;

void nullPtr(int *i) {
  if(i) g = *i;
}
