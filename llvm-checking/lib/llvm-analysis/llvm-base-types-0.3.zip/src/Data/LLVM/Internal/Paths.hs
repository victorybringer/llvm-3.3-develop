module Data.LLVM.Internal.Paths ( getDataFileName ) where

import Paths_llvm_base_types
