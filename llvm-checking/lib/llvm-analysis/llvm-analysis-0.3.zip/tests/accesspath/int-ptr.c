extern int * p;
void f() {
  *p = 1;
}
