extern int *arr;

void f() {
  arr[1] = 5;
}
