int arr[100];

void f() {
  arr[1] = 5;
}
