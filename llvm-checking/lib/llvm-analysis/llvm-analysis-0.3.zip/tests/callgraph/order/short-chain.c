void f()
{
}

void g()
{
  f();
}

int main(int argc, char *argv[])
{
  g();
  return 0;
}
