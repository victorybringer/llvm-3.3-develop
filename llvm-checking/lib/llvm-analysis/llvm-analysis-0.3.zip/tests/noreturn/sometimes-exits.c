#include <stdlib.h>

void f(int x) {
  if(x > 10)
    exit(100);
}
