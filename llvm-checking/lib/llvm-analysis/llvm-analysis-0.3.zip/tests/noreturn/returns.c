int f() {
  return 100;
}
