int f(int x) {
  while(1) {}

  return x;
}
