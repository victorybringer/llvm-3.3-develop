#include <stdlib.h>

void f(int x) {
  exit(x);
}
