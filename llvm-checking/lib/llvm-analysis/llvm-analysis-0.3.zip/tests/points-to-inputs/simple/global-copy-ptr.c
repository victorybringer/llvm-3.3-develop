int z;
int * p;
int * q = &z;

int ** pp;
int ** pq;

void copyPtr() {
  p = q;
}
