int a;
int b;

int * p;
int * q;
int ** pp;
int ** pq;

// Case 1
void storeAddress()
{
  p = &a;
}
