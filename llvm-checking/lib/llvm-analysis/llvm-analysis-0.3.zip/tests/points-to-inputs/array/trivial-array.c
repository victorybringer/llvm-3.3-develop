int a;
int b;
int c;
int d;

int arr[10];

int * p;
int * q;
int * r;
int ** pq;
int ** pp;


void caller()
{
  p = &arr[c];
}

void setup()
{
  q = &a;
  r = &b;
//  pp = &p;
}
