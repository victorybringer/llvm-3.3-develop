int a;
int c;

int** arr;

int * p;
int * r;

void setup()
{
  p = &a;
  arr[c] = p;
}

void target() {
  r = arr[a];
}
