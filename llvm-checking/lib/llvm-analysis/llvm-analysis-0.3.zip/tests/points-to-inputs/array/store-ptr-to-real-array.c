int a;
int c;

int* arr[100];

int * p;
int * r;

void setup()
{
  p = &a;
  r = arr[a];
  arr[c] = p;
}
