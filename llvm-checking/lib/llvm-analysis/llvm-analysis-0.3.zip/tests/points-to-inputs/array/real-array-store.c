int a;
int b;
int c;
int d;

int* arr[10];

int * p;
int * q;
int * r;
int ** pq;
int ** pp;


void caller()
{
  p = arr[c]; // arr[c] = b;
}

void setup()
{
  q = &a;
  r = &b;
  arr[a] = q;
//  pp = &p;
}
