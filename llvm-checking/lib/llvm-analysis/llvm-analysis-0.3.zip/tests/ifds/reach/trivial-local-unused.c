int main() {
  int y;
  int * p;
  y = 10;
  y += 7;
  y = y & 10;

  return 0;
}
