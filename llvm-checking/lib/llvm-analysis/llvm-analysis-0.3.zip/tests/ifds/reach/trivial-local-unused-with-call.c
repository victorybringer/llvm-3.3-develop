void f();
int main() {
  int y;
  int * p;
  y = 10;
  f();
  y += 7;
  y = y & 10;

  return 0;
}
