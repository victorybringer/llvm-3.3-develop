int *g;
int y;
int main() {
  y = 16;
  y *= 10;
  y = y / 4;
  return 0;
}
