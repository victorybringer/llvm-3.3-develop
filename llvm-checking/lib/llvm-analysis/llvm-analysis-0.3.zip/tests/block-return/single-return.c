int f() {
  return 5;
}
