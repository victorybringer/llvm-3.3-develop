
#ifndef _BUFFEROVERFLOW_STRCPY_USEEXLEN_CASE01_H_
#define _BUFFEROVERFLOW_STRCPY_USEEXLEN_CASE01_H_  

#include "common_structures.h"


#ifdef __cplusplus
extern "C" {
#endif

extern UINT32 FileFcopy(TLV *file, UINT32 len);

#ifdef __cplusplus
}
#endif
#endif

