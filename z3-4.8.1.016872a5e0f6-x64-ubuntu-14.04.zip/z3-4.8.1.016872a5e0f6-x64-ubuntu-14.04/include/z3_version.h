// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   8
#define Z3_BUILD_NUMBER    1
#define Z3_REVISION_NUMBER 9857

#define Z3_FULL_VERSION    "Z3 4.8.1.9857 016872a5e0f6 master z3-4.6.0-2081-g016872a5e"
